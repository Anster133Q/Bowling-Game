var Movement = pc.createScript('movement');

Movement.attributes.add('maxPower', {
    type: 'number',
    default: 25,
    description: 'Maximum power when space is fully charged'
});

Movement.attributes.add('chargeRate', {
    type: 'number',
    default: 10,
    description: 'Power per second while holding space'
});

Movement.attributes.add('sideSpeed', {
    type: 'number',
    default: 5,
    description: 'Side movement speed for aiming'
});

Movement.prototype.initialize = function () {
    this.force = new pc.Vec3();

    this.rollInProgress = false;
    this.isCharging = false;
    this.chargePower = 0;

    this.scoreboard = this.app.root.findByName('Scoreboard');
    this.currentFrame = 0;
    this.currentRoll = 0;
};

Movement.prototype.update = function (dt) {
    // Only allow movement if not rolling
    if (!this.rollInProgress) {
        this.handleAiming(dt);
        this.handleCharging(dt);
    }

    // Check if roll finished
    var velocity = this.entity.rigidbody.linearVelocity;
    if (this.rollInProgress && velocity.length() < 0.05) {
        this.rollInProgress = false;
        this.handleScoring();
    }
};

// Allow side movement for alignment
Movement.prototype.handleAiming = function (dt) {
    var moveX = 0;

    if (this.app.keyboard.isPressed(pc.KEY_LEFT)) {
        moveX = -this.sideSpeed * dt;
    }

    if (this.app.keyboard.isPressed(pc.KEY_RIGHT)) {
        moveX += this.sideSpeed * dt;
    }

    if (moveX !== 0) {
        var pos = this.entity.getPosition();
        this.entity.setPosition(pos.x + moveX, pos.y, pos.z);
    }
};

// Handle space key charge and release
Movement.prototype.handleCharging = function (dt) {
    var spacePressed = this.app.keyboard.isPressed(pc.KEY_SPACE);

    if (spacePressed) {
        this.isCharging = true;
        this.chargePower += this.chargeRate * dt;
        if (this.chargePower > this.maxPower) this.chargePower = this.maxPower;
    }

    if (this.isCharging && this.app.keyboard.wasReleased(pc.KEY_SPACE)) {
        this.launchBall(this.chargePower);
        this.chargePower = 0;
        this.isCharging = false;
        this.rollInProgress = true;
    }
};

// Apply forward force based on charge
Movement.prototype.launchBall = function (power) {
    var forward = new pc.Vec3(0, 0, -1);
    forward.normalize().scale(power);
    this.entity.rigidbody.applyImpulse(forward);
};

// Scoring system
Movement.prototype.handleScoring = function () {
    var pinsKnocked = Math.floor(Math.random() * 11);

    this.scoreboard.script.scoreboard.setRoll(this.currentFrame, this.currentRoll, pinsKnocked);

    if (this.currentRoll === 0) {
        this.currentRoll = 1;
    } else {
        var roll1 = parseInt(this.scoreboard.script.scoreboard.frames[this.currentFrame].roll1.text || 0);
        var roll2 = parseInt(this.scoreboard.script.scoreboard.frames[this.currentFrame].roll2.text || 0);
        var total = roll1 + roll2;

        this.scoreboard.script.scoreboard.setTotal(this.currentFrame, total);

        this.currentFrame++;
        this.currentRoll = 0;

        if (this.currentFrame >= 10) {
            this.currentFrame = 9;
            this.currentRoll = 1;
        }
    }

    // Reset position
    this.entity.rigidbody.teleport(0, 1, 0);
    this.entity.rigidbody.linearVelocity = pc.Vec3.ZERO.clone();
    this.entity.rigidbody.angularVelocity = pc.Vec3.ZERO.clone();
};
