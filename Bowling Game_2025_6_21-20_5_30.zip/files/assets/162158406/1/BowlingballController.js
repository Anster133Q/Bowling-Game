var BowlingBallMovement = pc.createScript('bowlingBallMovement');

BowlingBallMovement.attributes.add('speed', { type: 'number', default: 5 });

// initialize code called once per entity
BowlingBallMovement.prototype.initialize = function() {
    // Initialize variables or access other entities/components here
};

// update code called every frame
BowlingBallMovement.prototype.update = function(dt) {
    // Move the ball forward based on speed and current direction
    this.entity.translateLocal(0, 0, -this.speed * dt);
};

// Functions to control the ball's movement
BowlingBallMovement.prototype.moveLeft = function() {
    this.entity.rotateLocal(0, -5, 0); // Rotate left
};

BowlingBallMovement.prototype.moveRight = function() {
    this.entity.rotateLocal(0, 5, 0); // Rotate right
};

// Example key handling for movement
BowlingBallMovement.prototype.onKeyDown = function(event) {
    if (event.key === pc.KEY_LEFT) {
        this.moveLeft();
    } else if (event.key === pc.KEY_RIGHT) {
        this.moveRight();
    }
};
