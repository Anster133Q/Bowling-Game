var Scoreboard = pc.createScript('scoreboard');

Scoreboard.prototype.initialize = function () {
    this.frames = [];

    for (let i = 1; i <= 10; i++) {
        const frameEntity = this.entity.findByName('Frame' + i);
        const roll1 = frameEntity.findByName('Roll1').element;
        const roll2 = frameEntity.findByName('Roll2').element;
        const total = frameEntity.findByName('Total').element;

        this.frames.push({ roll1, roll2, total });
    }

    const bonusEntity = this.entity.findByName('Bonus');
    this.bonus = bonusEntity.element;
};

// frameIndex: 0-9, rollIndex: 0 or 1
Scoreboard.prototype.setRoll = function (frameIndex, rollIndex, value) {
    const frame = this.frames[frameIndex];
    if (rollIndex === 0) {
        frame.roll1.text = value.toString();
    } else {
        frame.roll2.text = value.toString();
    }
};

Scoreboard.prototype.setTotal = function (frameIndex, total) {
    this.frames[frameIndex].total.text = total.toString();
};

Scoreboard.prototype.setBonus = function (value) {
    this.bonus.text = value.toString();
};
